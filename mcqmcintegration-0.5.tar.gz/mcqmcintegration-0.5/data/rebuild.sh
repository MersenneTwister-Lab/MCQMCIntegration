sqlite3 digitalnet.sqlite3 vacuum
sqlite3 digitalnet.sqlite3 reindex
